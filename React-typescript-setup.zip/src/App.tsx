import React from "react";
import "./App.css";
import Routes from "./Routes";

function App(): React.JSX.Element {
  return <Routes />;
}

export default App;
